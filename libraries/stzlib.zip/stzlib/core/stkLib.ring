
load "stzcore.ring"
