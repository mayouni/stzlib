
load "../stzbase.ring"

# stzTimex Test Suite - Updated for Match/MatchPartial semantics

/*--- Example 1: Basic Instant Matching
*/
pr()

# Match single timestamp

Tmx = Tmx("{@Instant}")
? Tmx.Match(StzDateTimeQ("2025-10-22 14:30:00"))
#--> TRUE (exact match)

? Tmx.MatchPartial(StzDateTimeQ("2025-10-22 14:30:00"))
#--> TRUE (partial also works for single item)

pf()

/*--- Example 2: Duration Constraints with Steps

pr()

oDur1 = new stzDuration("1 hour 30 minutes")  # 90 minutes
oDur2 = new stzDuration("1 hour 20 minutes")  # 80 minutes

Tmx = new stzTimex("{@Duration(1h..2h:15min)}")

? Tmx.Match(oDur1)
#--> TRUE (90min is in range and on 15min boundary)

? Tmx.Match(oDur2)
#--> FALSE (80min not on 15min step: 60, 75, 90, 105, 120)

pf()

/*--- Example 3: Event Sequences - Match vs MatchPartial

pr()

oTimeline = new stzTimeLine("2025-10-22", "2025-10-22")
oTimeline.AddInstant("Meeting", "2025-10-22 09:00:00")
oTimeline.AddSpan("Break", "2025-10-22 10:00:00", "2025-10-22 10:15:00")
oTimeline.AddInstant("Lunch", "2025-10-22 12:00:00")

# Pattern: Meeting -> any gaps -> Break
Tmx1 = new stzTimex("{@Event(Meeting) -> @Duration* -> @Event(Break)}")

# Match (exact - must consume all data):
? Tmx1.Match(oTimeline)
#--> FALSE (pattern stops at Break, but Lunch remains)

# MatchPartial (finds pattern anywhere):
? Tmx1.MatchPartial(oTimeline)
#--> TRUE (Meeting->Break sequence exists)

pf()

/*--- Example 4: Complete Sequence Matching

pr()

oTimeline2 = new stzTimeLine("2025-10-22", "2025-10-22")
oTimeline2.AddInstant("Start", "2025-10-22 09:00:00")
oTimeline2.AddSpan("Work", "2025-10-22 09:00:00", "2025-10-22 17:00:00")
oTimeline2.AddInstant("End", "2025-10-22 17:00:00")

# Pattern matches entire timeline
Tmx2 = new stzTimex("{@Event(Start) -> @Duration* -> @Event(Work) -> @Duration* -> @Event(End)}")

? Tmx2.Match(oTimeline2)
#--> TRUE (exact match - entire timeline consumed)

pf()

/*--- Example 5: Gap Duration Constraints

pr()

oTimeline3 = new stzTimeLine("2025-10-22", "2025-10-22")
oTimeline3.AddInstant("A", "2025-10-22 09:00:00")
oTimeline3.AddInstant("B", "2025-10-22 09:30:00")  # 30min gap
oTimeline3.AddInstant("C", "2025-10-22 10:00:00")  # 30min gap

# Match events with 30min gaps
Tmx3 = new stzTimex("{@Event(A) -> @Duration(30m) -> @Event(B)}")

? Tmx3.MatchPartial(oTimeline3)
#--> TRUE (finds A->30min->B)

# Try with wrong gap duration
Tmx4 = new stzTimex("{@Event(A) -> @Duration(1h) -> @Event(B)}")

? Tmx4.MatchPartial(oTimeline3)
#--> FALSE (gap is 30min, not 1h)

pf()

/*--- Example 6: Alternation Patterns

pr()

oTimeline4 = new stzTimeLine("2025-10-22", "2025-10-22")
oTimeline4.AddInstant("Meeting", "2025-10-22 09:00:00")
oTimeline4.AddSpan("Coffee", "2025-10-22 10:00:00", "2025-10-22 10:15:00")
oTimeline4.AddInstant("Lunch", "2025-10-22 12:00:00")

# Match Meeting followed by Coffee OR Lunch
Tmx5 = new stzTimex("{@Event(Meeting) -> @Duration* -> (@Event(Coffee)|@Event(Lunch))}")

? Tmx5.MatchPartial(oTimeline4)
#--> TRUE (Meeting->Coffee path matches)

pf()

/*--- Example 7: Event Span Duration Constraints

pr()

oTimeline5 = new stzTimeLine("2025-10-22", "2025-10-22")
oTimeline5.AddSpan("Session", "2025-10-22 09:00:00", "2025-10-22 10:00:00")  # 60min

# Match event that lasts exactly 1 hour
Tmx6 = new stzTimex("{@Event(Session:1h)}")

? Tmx6.Match(oTimeline5)
#--> TRUE (Session span is 60 minutes)

# Try with wrong duration
Tmx7 = new stzTimex("{@Event(Session:30m)}")

? Tmx7.Match(oTimeline5)
#--> FALSE (Session is 60min, not 30min)

pf()

/*--- Example 8: Quantifiers - Zero or More

pr()

oTimeline6 = new stzTimeLine("2025-10-22", "2025-10-22")
oTimeline6.AddInstant("Start", "2025-10-22 09:00:00")
oTimeline6.AddInstant("End", "2025-10-22 17:00:00")

# Match Start and End with any number of gaps between
Tmx8 = new stzTimex("{@Event(Start) -> @Duration* -> @Event(End)}")

? Tmx8.Match(oTimeline6)
#--> TRUE (@Duration* matches 1 gap)

pf()

/*--- Example 9: Adjacent Events (No Gaps)

pr()

oTimeline7 = new stzTimeLine("2025-10-22", "2025-10-22")
oTimeline7.AddSpan("Session1", "2025-10-22 09:00:00", "2025-10-22 10:00:00")
oTimeline7.AddSpan("Session2", "2025-10-22 10:00:00", "2025-10-22 11:00:00")

# Match adjacent events
Tmx9 = new stzTimex("{@Event(Session1) -> @Event(Session2)}")

? Tmx9.Match(oTimeline7)
#--> TRUE (events are adjacent, no gap required)

pf()

/*--- Example 10: Pattern Debugging

pr()

oTimeline8 = new stzTimeLine("2025-10-22", "2025-10-22")
oTimeline8.AddInstant("A", "2025-10-22 09:00:00")
oTimeline8.AddInstant("B", "2025-10-22 10:00:00")
oTimeline8.AddInstant("C", "2025-10-22 11:00:00")

Tmx10 = new stzTimex("{@Event(A) -> @Duration* -> @Event(C)}")
Tmx10.EnableDebug()

? Tmx10.MatchPartial(oTimeline8)
#--> TRUE (with detailed trace)
'
Token 1 (type=event, label=A): trying 1 matches starting at data position 1
  Attempt 1: checking data[1] type=instant, label=A
CheckConstraints: type=instant, label=A, constraints=0
Token 2 (type=duration, label=): trying 2 matches starting at data position 2
  Attempt 1: checking data[2] type=duration, label=
CheckConstraints: type=duration, label=, constraints=0
  Attempt 2: checking data[3] type=instant, label=B
  Attempt 2: checking data[4] type=duration, label=
CheckConstraints: type=duration, label=, constraints=0
Token 3 (type=event, label=C): trying 1 matches starting at data position 5
  Attempt 1: checking data[5] type=instant, label=C
CheckConstraints: type=instant, label=C, constraints=0
'

pf()

/*--- Example 11: Real-World Meeting Scheduler

pr()

oSchedule = new stzTimeLine("2025-10-22", "2025-10-22")
oSchedule.AddInstant("DayStart", "2025-10-22 08:00:00")
oSchedule.AddSpan("Standup", "2025-10-22 09:00:00", "2025-10-22 09:15:00")
oSchedule.AddSpan("DeepWork", "2025-10-22 09:30:00", "2025-10-22 12:00:00")
oSchedule.AddSpan("Lunch", "2025-10-22 12:00:00", "2025-10-22 13:00:00")

# Validate standup happens after day start
Tmx11 = new stzTimex("{@Event(DayStart) -> @Duration* -> @Event(Standup)}")

? Tmx11.MatchPartial(oSchedule)
#--> TRUE (pattern exists in schedule)

# Check for deep work session (2+ hours)
Tmx12 = new stzTimex("{@Event(DeepWork:2h..4h)}")

? Tmx12.MatchPartial(oSchedule)
#--> TRUE (DeepWork is 2.5 hours)

pf()

/*--- Example 12: Finding Patterns Across Timeline

pr()

oTimeline9 = new stzTimeLine("2025-10-22", "2025-10-22")
oTimeline9.AddInstant("X", "2025-10-22 08:00:00")
oTimeline9.AddInstant("Y", "2025-10-22 09:00:00")
oTimeline9.AddInstant("Target", "2025-10-22 10:00:00")
oTimeline9.AddInstant("Z", "2025-10-22 11:00:00")

# Find Target anywhere in timeline
Tmx13 = new stzTimex("{@Event(Target)}")

? Tmx13.MatchPartial(oTimeline9)
#--> TRUE (Target found at position 3)

pf()

/*--- Example 13: Pattern Explanation
*/
pr()

Tmx14 = new stzTimex("{@Event(Meeting) -> @Duration(30m..1h) -> @Event(Break)}")

? "Pattern structure:"
? @@NL(Tmx14.Explain())
#--> Shows tokens, constraints, and semantics
'
[
	[
		"Pattern",
		"{@Event(Meeting) -> @Duration(30m..1h) -> @Event(Break)}"
	],
	[ "TokenCount", 3 ],
	[
		"Tokens",
		[
			[
				[ "index", 1 ],
				[ "type", "event" ],
				[ "label", "Meeting" ]
			],
			[
				[ "index", 2 ],
				[ "type", "duration" ],
				[ "label", "" ],
				[
					"constraints",
					[
						[
							[ "type", "range" ],
							[ "start", "30m" ],
							[ "end", "1h" ],
							[ "step", "" ]
						]
					]
				]
			],
			[
				[ "index", 3 ],
				[ "type", "event" ],
				[ "label", "Break" ]
			]
		]
	],
	[ "TargetSet", 1 ],
	[ "LastMatch", 0 ]
]
'
pf()
