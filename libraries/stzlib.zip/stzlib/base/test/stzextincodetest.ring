load "../stzbase.ring"

