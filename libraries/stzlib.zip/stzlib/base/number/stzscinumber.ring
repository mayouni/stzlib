class stzSciNumber from stkSciNumber
